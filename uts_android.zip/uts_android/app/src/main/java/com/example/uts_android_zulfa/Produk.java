package com.example.uts_android_zulfa;

public class Produk {
    String id, brand, nama_barang, kode_warna, harga;

    public Produk(String id, String brand, String nama_barang, String kode_warna, String harga) {
        this.id = id;
        this.brand = brand;
        this.nama_barang = nama_barang;
        this.kode_warna = kode_warna;
        this.harga = harga;
    }

    public String getId() {
        return id;
    }

    public String getBrand() { return brand; }

    public String getNamaBarang() {
        return nama_barang;
    }

    public String getKodeWarna() {
        return kode_warna;
    }

    public String getHarga() {
        return harga;
    }
}
